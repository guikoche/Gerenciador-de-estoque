<?php

use PHPUnit\Framework\TestCase;

class AddProductPageTest extends TestCase
{
    public function testPageElements()
    {
        ob_start();
        include '.../views/itens/additens.php'; // Substitua pelo caminho correto do seu arquivo
        $output = ob_get_clean();

        // Verifica se os elementos principais estão presentes na página
        $this->assertStringContainsString('<form role="form"', $output);
        $this->assertStringContainsString('Nome do Produto', $output);
        $this->assertStringContainsString('Fabricante', $output);
        $this->assertStringContainsString('QuantItens', $output);
        $this->assertStringContainsString('ValCompItens', $output);
        $this->assertStringContainsString('ValVendItens', $output);
        $this->assertStringContainsString('DataCompraItens', $output);
        $this->assertStringContainsString('DataVenci_Itens', $output);
        $this->assertStringContainsString('Imagem', $output);
        $this->assertStringContainsString('Cadastrar', $output);
        $this->assertStringContainsString('Cancelar', $output);
    }
}
