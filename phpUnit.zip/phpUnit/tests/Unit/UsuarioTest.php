<?php

use PHPUnit\Framework\TestCase;

class AddUserPageTest extends TestCase
{
    public function testAdminPermission()
    {
        // Defina a variável $perm como administrador (valor 1)
        $perm = 1;

        ob_start();
        include '../../views/addusuarios.php'; // Inclua o código que precisa ser testado
        $output = ob_get_clean();

        // Verifica se a página é exibida corretamente para um administrador
        $this->assertStringContainsString('<form role="form"', $output);
        $this->assertStringContainsString('Nome do usuário', $output);
        $this->assertStringContainsString('E-mail do usuário', $output);
        $this->assertStringContainsString('Password', $output);
        $this->assertStringContainsString('Foto Perfil', $output);
        $this->assertStringContainsString('Cadastrar', $output);
        $this->assertStringNotContainsString('Você não possui acesso!', $output);
    }

    public function testNonAdminPermission()
    {
        // Defina a variável $perm como não administrador (valor diferente de 1)
        $perm = 2;

        ob_start();
        include '../../App/add_user_page.php'; // Inclua o código que precisa ser testado
        $output = ob_get_clean();

        // Verifica se a mensagem de acesso negado é exibida corretamente para não administradores
        $this->assertStringContainsString('Você não possui acesso!', $output);
        $this->assertStringNotContainsString('<form role="form"', $output);
        $this->assertStringNotContainsString('Cadastrar', $output);
    }
}
