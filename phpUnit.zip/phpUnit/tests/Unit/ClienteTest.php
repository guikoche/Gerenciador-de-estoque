<?php
use PHPUnit\Framework\TestCase;

class ClienteTest extends TestCase
    {
    // Mock para simular um banco de dados de teste ou classe Cliente

    public function testInsertCliente()
    {
    // Simular inserção de cliente e verificar se o retorno é o esperado
    $cliente = new Cliente();
    $result = $cliente->InsertCliente('NomeTeste', 'email@teste.com', '123456789', $idUsuario, $perm);

    $this->assertEquals('MensagemEsperada', $result);
    }

    public function testUpdateCliente()
    {
    // Simular atualização de cliente e verificar se o retorno é o esperado
    $cliente = new Cliente(); 
    $result = $cliente->UpdateCliente(1, 'NovoNome', 'novoemail@teste.com', '987654321', $idUsuario, $perm);

    $this->assertEquals('MensagemEsperada', $result);
        }
    }