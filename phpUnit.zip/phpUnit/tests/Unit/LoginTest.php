<?php

use PHPUnit\Framework\TestCase;

class SessionTest extends TestCase
{
public function testSessionRedirectsToLogin()
{
// Definido um array vazio para simular uma sessão sem variáveis definidas
$_SESSION = [];
require_once '.../App/auth.php';
// Verificar se houve redirecionamento para '../'
$this->assertStringContainsString('Location: ../', xdebug_get_headers()[0]);
}

public function testSessionVariablesAreSet()
{
// Simular variáveis de sessão definidas
$_SESSION["idUsuario"] = 1;
$_SESSION["usuario"] = "username";
$_SESSION["perm"] = "permissao";
$_SESSION["foto"] = "foto";

// Incluir o arquivo PHP
require_once '.../App/auth.php';

// Verifica se as variáveis de sessão foram definidas corretamente
$this->assertEquals(1, $idUsuario);
$this->assertEquals("username", $username);
$this->assertEquals("permissao", $perm);
$this->assertEquals("foto", $foto);
    }   
}