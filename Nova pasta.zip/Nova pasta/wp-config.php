<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u568843292_controlestoque' );

/** Database username */
define( 'DB_USER', 'u568843292_root' );

/** Database password */
define( 'DB_PASSWORD', 'Gui48772017#' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '%N ~R2l^WRYR8Z`WOV5<fMB1eF]h1[!!`[of5TdH}(O3v1t8p!YPp(u/6EO[HG[[' );
define( 'SECURE_AUTH_KEY',   '(r!ky@Wz<+^I<2,;Vf6W]Mdn^pwc|;cQH@IQy#oYGFQ&uX^^ ^i@SrqLcOck{4W5' );
define( 'LOGGED_IN_KEY',     ',rSjN[M?#,{,2{U-f`Tn0l-WU1}xyBhHrZ.Pqgu_J4gqNw4Is k=bEzv!{p&C-~^' );
define( 'NONCE_KEY',         '#n.O,;c 9t!J^q4}f=ZhgS_2R]ns)&/Ouao[/L}U11b^!:.NCs~,=01H>+$$U_>*' );
define( 'AUTH_SALT',         'V7IA~RGn2Gqu-R(T7}jw7YqG+1sKbZ^,_lHn+C{8S_)bPSO)8}5,_OG{K)9*%%pS' );
define( 'SECURE_AUTH_SALT',  'E_D0-C7n-%/G`cD6@myy_O<w7zaZZxy&YP])oHuKld^WvwcX>.nJD7Ud1aa=}pn$' );
define( 'LOGGED_IN_SALT',    '|%ZaV1k%ug){rab{nN|?vn0wPS0cH;$MDf9Ite<[tvx7;?Km?<p~0lEuXuPvO#ZG' );
define( 'NONCE_SALT',        'I0GvC#c}O,y?)U_a2bKtx;-<7*LTB6<u:+*2u8zyOr.R1PW,aYAi!e{I^C~Iy{_n' );
define( 'WP_CACHE_KEY_SALT', '8UEMea$Zk7[$RL`udq9kVvWz8ToQ{pX]6w/A*hKXMw$9=6SSGzpEdDV/R&b-C{Hj' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );


/* Add any custom values between this line and the "stop editing" line. */



define( 'FS_METHOD', 'direct' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
